import { Component, signal } from '@angular/core';
import { NuevoMovimientoComponent } from '../nuevo-movimiento/nuevo-movimiento.component';
import { Movimiento, SolicitudMovimiento } from '../movimiento.model';

/** Único dueño del saldo y del historial. */
@Component({
  selector: 'app-billetera',
  standalone: true,
  imports: [NuevoMovimientoComponent],
  templateUrl: './billetera.component.html'
})
export class BilleteraComponent {
  readonly saldo = signal(250);
  readonly movimientos = signal<Movimiento[]>([]);
  private siguienteId = 1;

  registrarMovimiento(solicitud: SolicitudMovimiento): void {
    // Protección extra del estado del padre, aun si se llamara manualmente al método.
    if (!Number.isFinite(solicitud.monto) || solicitud.monto <= 0 ||
        Math.round(solicitud.monto * 100) / 100 !== solicitud.monto ||
        (solicitud.tipo !== 'Recarga' && solicitud.tipo !== 'Gasto') ||
        (solicitud.tipo === 'Gasto' && solicitud.monto > this.saldo())) {
      return;
    }

    const cambio = solicitud.tipo === 'Recarga' ? solicitud.monto : -solicitud.monto;
    this.saldo.update(actual => Math.round((actual + cambio) * 100) / 100);
    this.movimientos.update(historial => [
      { ...solicitud, id: this.siguienteId++ }, ...historial
    ]);
  }
}
