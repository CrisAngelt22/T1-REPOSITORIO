export type TipoMovimiento = 'Recarga' | 'Gasto';

export interface SolicitudMovimiento {
  tipo: TipoMovimiento;
  monto: number;
}

export interface Movimiento extends SolicitudMovimiento {
  id: number;
}
