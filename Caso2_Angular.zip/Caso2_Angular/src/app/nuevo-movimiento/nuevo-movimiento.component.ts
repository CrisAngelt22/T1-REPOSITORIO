import { Component, computed, input, output, signal } from '@angular/core';
import { SolicitudMovimiento, TipoMovimiento } from '../movimiento.model';

/** Valida y notifica; nunca altera el saldo ni el historial. */
@Component({
  selector: 'app-nuevo-movimiento',
  standalone: true,
  templateUrl: './nuevo-movimiento.component.html'
})
export class NuevoMovimientoComponent {
  readonly saldo = input.required<number>();
  readonly movimientoValido = output<SolicitudMovimiento>();
  readonly tipo = signal<TipoMovimiento>('Recarga');
  readonly montoTexto = signal('');

  readonly mensajeError = computed(() => {
    const texto = this.montoTexto().trim();
    if (!texto) return 'Ingresa un monto para continuar.';
    const monto = Number(texto);
    if (!Number.isFinite(monto)) return 'Ingresa un monto numérico válido.';
    if (monto <= 0) return 'El monto debe ser mayor que cero.';
    if (!/^\d+(\.\d{1,2})?$/.test(texto)) return 'Usa como máximo dos decimales.';
    if (this.tipo() === 'Gasto' && monto > this.saldo()) return 'Saldo insuficiente para realizar el gasto.';
    return '';
  });

  readonly puedeRegistrar = computed(() => this.mensajeError() === '');

  cambiarTipo(value: string): void {
    if (value === 'Recarga' || value === 'Gasto') this.tipo.set(value);
  }

  registrar(): void {
    if (!this.puedeRegistrar()) return;
    this.movimientoValido.emit({ tipo: this.tipo(), monto: Number(this.montoTexto()) });
    this.montoTexto.set('');
  }
}
