import { Component } from '@angular/core';
import { BilleteraComponent } from './billetera/billetera.component';

/** AppComponent es únicamente el contenedor (no hace cálculos). */
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [BilleteraComponent],
  template: '<app-billetera />'
})
export class AppComponent {}
