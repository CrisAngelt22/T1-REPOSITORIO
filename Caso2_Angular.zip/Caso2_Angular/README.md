Caso 2 – Billetera Digital Angular

Aplicación independiente desarrollada en Angular

Versiones
- Angular 20.3.x
- Node.js 24.15.0 (versión utilizada)
- npm 11.12.1 (versión utilizada)
- Bootstrap 5.3.x
- TypeScript 5.9.x

Ejecución en VS Code (Windows)
1. Extrae este ZIP en una carpeta diferente
2. Abre `Caso2_Angular` en VS Code
3. Abre Terminal - Nueva terminal
4. Ejecuta `npm install`
5. Ejecuta `npm start`
6. Abre `http://localhost:4200/`


Organización

- `BilleteraComponent` (padre) mantiene el saldo con `signal(250)` y el historial con `signal([])`. Muestra historial con `@for` y mensaje vacío con `@if`

- `NuevoMovimientoComponent` (hijo) recibe el saldo mediante `input()`, valida el monto y el saldo, deshabilita el botón con `[disabled]` cuando la solicitud no es válida y emite la solicitud con `output()`

- `AppComponent` solo contiene la billetera

Pruebas

Realiza las pruebas independientemente

1. Al abrir: S/ 250.00 y ningún movimiento
2. Recarga S/ 100.00: saldo S/ 350.00 y recarga en historial
3. Gasto S/ 50.00: saldo S/ 300.00 y gasto primero en historial
4. Gasto S/ 400.00: error de saldo insuficiente, botón deshabilitado, sin cambios
5. Monto vacío, cero, negativo o no válido: botón deshabilitado y sin cambios

Los datos se mantienen exclusivamente en memoria del componente padre, al recargar el navegador, la aplicación inicia de nuevo en S/ 250.00
