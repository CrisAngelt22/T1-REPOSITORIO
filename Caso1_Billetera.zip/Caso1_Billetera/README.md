Caso 1 — Billetera Digital (Servlet + JSP)

Proyecto independiente de Java puro

Requisitos

- JDK 17 o superior
- Apache Maven 3.9 o superior
- **Apache Tomcat 10.1** (Jakarta Servlet 6). No usar Tomcat 9

Compilar y generar el archivo .war

```bash

mvn clean package

```

El resultado será `target/billetera-servlet.war`.

Ejecutar

1. Copiar `target/billetera-servlet.war` a la carpeta `webapps` de Tomcat 10.1
2. Iniciar Tomcat
3. Abrir `http://localhost:8080/billetera-servlet/`



Cómo se programó

- BilleteraServlet: maneja GET y POST, valida y envía datos con `forward()` a la JSP
- Billetera: mantiene saldo de S/ 250.00 y lista de movimientos en `HttpSession`
- Movimiento: representa tipo y monto
- billetera.jsp: HTML, Bootstrap, JSTL `<c:forEach>` y expresiones EL; **sin scriptlets**
- El historial se agrega **al principio** y no cambia si el POST es inválido


Prueba exigida por la evaluación

1. Abrir: saldo S/ 250.00, historial vacío
2. `Recarga` `100.00`: saldo S/ 350.00, recarga en historial
3. `Gasto` `50.00`: saldo S/ 300.00, gasto al inicio del historial
4. `Gasto` `400.00`: error de saldo insuficiente, sin modificar datos
5. Montos `0`, `-5`, vacío, texto: se rechazan, saldo/historial intactos

En el Caso 1 los montos se validan siempre en el servidor incluso si alguien omite las restricciones del formulario HTML  la sesión se reinicia si se cierra/invalida la sesión del navegador o vence por inactividad.

