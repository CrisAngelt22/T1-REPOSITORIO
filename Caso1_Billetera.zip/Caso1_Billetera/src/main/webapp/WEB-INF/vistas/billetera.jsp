<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ taglib prefix="fmt" uri="jakarta.tags.fmt" %>
<!doctype html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Billetera Clara | Java</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f6f7fb; color:#1e293b; }
    .shell { max-width:1000px; }
    .topbar { background:#fff; border-bottom:1px solid #e8ebf0; }
    .brand-dot { width:13px; height:13px; background:#0d9488; border-radius:50%; display:inline-block; }
    .balance { background:linear-gradient(120deg,#0f766e,#115e59); color:white; border-radius:20px; }
    .soft-card { border:1px solid #e7eaf0; border-radius:18px; box-shadow:0 8px 25px rgba(15,23,42,.035); }
    .label-muted { font-size:.81rem; letter-spacing:.07em; text-transform:uppercase; }
    .amount { font-size:clamp(2.25rem,5vw,3.4rem); letter-spacing:-.06em; font-weight:700; }
  </style>
</head>
<body>
  <header class="topbar py-3"><div class="container shell d-flex justify-content-between align-items-center">
    <div class="d-flex gap-2 align-items-center fw-bold"><span class="brand-dot"></span> Billetera Clara</div>
    <span class="badge bg-light text-secondary border">Versión Java · JSP</span>
  </div></header>
  <main class="container shell py-4 py-md-5">
    <div class="mb-4"><div class="text-secondary small">PANEL PERSONAL</div><h1 class="h3 fw-bold mt-1">Control de movimientos</h1>
      <p class="text-secondary mb-0">Consulta tu saldo, agrega una recarga o registra un gasto.</p></div>
    <div class="row g-4">
      <section class="col-lg-5">
        <div class="balance p-4 mb-4">
          <div class="label-muted opacity-75">Saldo disponible</div>
          <div class="amount mt-3">S/ <fmt:formatNumber value="${billetera.saldo}" pattern="#,##0.00"/></div>
          <div class="opacity-75 small mt-2">Actualizado con tus movimientos</div>
        </div>
        <div class="card soft-card p-4">
          <h2 class="h5 fw-bold">Nuevo movimiento</h2>
          <p class="small text-secondary">Completa los datos para actualizar tu billetera.</p>
          <c:if test="${not empty error}"><div class="alert alert-danger py-2" role="alert"><c:out value="${error}"/></div></c:if>
          <c:if test="${not empty mensaje}"><div class="alert alert-success py-2" role="status"><c:out value="${mensaje}"/></div></c:if>
          <form method="post" action="${pageContext.request.contextPath}/billetera" novalidate>
            <div class="mb-3"><label class="form-label fw-semibold" for="tipo">Tipo</label>
              <select name="tipo" id="tipo" class="form-select" required>
                <option value="Recarga">Recarga (+)</option><option value="Gasto">Gasto (-)</option>
              </select></div>
            <div class="mb-4"><label class="form-label fw-semibold" for="monto">Monto (S/)</label>
              <input class="form-control" type="number" name="monto" id="monto" step="0.01" min="0.01" placeholder="Ejemplo: 100.00" required>
              <div class="form-text">Solo montos positivos, hasta dos decimales.</div></div>
            <button class="btn btn-success w-100 py-2" type="submit">Registrar movimiento</button>
          </form>
        </div>
      </section>
      <section class="col-lg-7"><div class="card soft-card p-4 h-100">
        <div class="d-flex flex-wrap justify-content-between gap-2 align-items-center mb-3">
          <h2 class="h5 fw-bold mb-0">Historial de movimientos</h2>
          <span class="badge text-bg-light border">${billetera.movimientos.size()} movimientos</span>
        </div>
        <c:choose>
          <c:when test="${empty billetera.movimientos}">
            <div class="text-center py-5 my-auto"><div class="display-5 text-secondary">◎</div>
              <p class="fw-semibold mb-1">Aún no hay movimientos</p>
              <p class="text-secondary small mb-0">Aquí aparecerán las recargas y gastos realizados.</p></div>
          </c:when>
          <c:otherwise>
            <div class="table-responsive"><table class="table align-middle">
              <thead><tr><th>Tipo</th><th class="text-end">Monto</th></tr></thead>
              <tbody><c:forEach var="mov" items="${billetera.movimientos}">
                <tr><td><span class="badge ${mov.recarga ? 'text-bg-success' : 'text-bg-danger'}"><c:out value="${mov.tipo}"/></span></td>
                <td class="text-end fw-semibold ${mov.recarga ? 'text-success' : 'text-danger'}">
                  ${mov.recarga ? '+' : '-'} S/ <fmt:formatNumber value="${mov.monto}" pattern="#,##0.00"/>
                </td></tr>
              </c:forEach></tbody>
            </table></div>
          </c:otherwise>
        </c:choose>
      </div></section>
    </div>
</body></html>
