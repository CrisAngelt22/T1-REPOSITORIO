package pe.edu.t1.billetera.web;

import pe.edu.t1.billetera.modelo.Billetera;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;

@WebServlet("/billetera")
public class BilleteraServlet extends HttpServlet {
    private static final String VISTA = "/WEB-INF/vistas/billetera.jsp";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession sesion = request.getSession();
        synchronized (sesion) {
            Billetera billetera = obtenerBilletera(sesion);
            request.setAttribute("billetera", billetera);
            request.getRequestDispatcher(VISTA).forward(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        HttpSession sesion = request.getSession();
        synchronized (sesion) {
            Billetera billetera = obtenerBilletera(sesion);
            String tipo = request.getParameter("tipo");
            String entrada = request.getParameter("monto");
            String error = null;
            BigDecimal monto = null;

            if (!"Recarga".equals(tipo) && !"Gasto".equals(tipo)) {
                error = "Selecciona un tipo de movimiento válido.";
            } else if (entrada == null || entrada.trim().isEmpty()) {
                error = "Ingresa un monto para continuar.";
            } else {
                try {
                    monto = new BigDecimal(entrada.trim());
                    if (monto.signum() <= 0) {
                        error = "El monto debe ser mayor que cero.";
                    } else if (monto.scale() > 2) {
                        error = "El monto debe tener como máximo dos decimales.";
                    } else if ("Gasto".equals(tipo) && monto.compareTo(billetera.getSaldo()) > 0) {
                        error = "Saldo insuficiente para realizar el gasto.";
                    }
                } catch (NumberFormatException exception) {
                    error = "Ingresa un monto numérico válido.";
                }
            }

            if (error == null) {
                billetera.registrar(tipo, monto.setScale(2, RoundingMode.UNNECESSARY));
                request.setAttribute("mensaje", tipo + " registrada correctamente.");
            } else {
                request.setAttribute("error", error);
            }
            request.setAttribute("billetera", billetera);
            request.getRequestDispatcher(VISTA).forward(request, response);
        }
    }

    private Billetera obtenerBilletera(HttpSession sesion) {
        Billetera billetera = (Billetera) sesion.getAttribute("billetera");
        if (billetera == null) {
            billetera = new Billetera();
            sesion.setAttribute("billetera", billetera);
        }
        return billetera;
    }
}
