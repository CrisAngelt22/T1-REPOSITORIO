package pe.edu.t1.billetera.modelo;

import java.io.Serializable;
import java.math.BigDecimal;

/** Registro sencillo de una operación válida. */
public class Movimiento implements Serializable {
    private final String tipo;
    private final BigDecimal monto;

    public Movimiento(String tipo, BigDecimal monto) {
        this.tipo = tipo;
        this.monto = monto;
    }

    public String getTipo() { return tipo; }
    public BigDecimal getMonto() { return monto; }
    public boolean isRecarga() { return "Recarga".equals(tipo); }
}
