package pe.edu.t1.billetera.modelo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** El estado se guarda exclusivamente en la sesión HTTP. */
public class Billetera implements Serializable {
    private BigDecimal saldo = new BigDecimal("250.00");
    private final List<Movimiento> movimientos = new ArrayList<>();

    public BigDecimal getSaldo() { return saldo; }
    public List<Movimiento> getMovimientos() { return Collections.unmodifiableList(movimientos); }

    public void registrar(String tipo, BigDecimal monto) {
        saldo = "Recarga".equals(tipo) ? saldo.add(monto) : saldo.subtract(monto);
        movimientos.add(0, new Movimiento(tipo, monto)); // primero el más reciente
    }
}
